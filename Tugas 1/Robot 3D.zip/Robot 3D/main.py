import http.server
import socketserver
import webbrowser
import os

PORT = 8000
DIRECTORY = "static"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

# Buka browser secara otomatis
url = f"http://localhost:{PORT}/index.html"
print(f"Server berjalan di {url}")
webbrowser.open(url)

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print("Tekan Ctrl+C untuk menghentikan server")
    httpd.serve_forever()
