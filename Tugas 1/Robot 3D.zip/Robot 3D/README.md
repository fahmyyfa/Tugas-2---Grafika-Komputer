# 🤖 Simple 3D Robot Visualization

Sebuah proyek edukatif 3D berbasis WebGL menggunakan **Three.js** untuk memvisualisasikan model robot sederhana, terdiri dari:

- **Kubus** (badan)
- **Silinder** (leher)
- **Bola** (mata)
- **Balok** (tangan)
- **Kerucut** (antena)

## 🎯 Fitur Proyek

- 🔷 **5 objek 3D dasar** digunakan secara simultan.
- 🎨 Visualisasi dengan pencahayaan dan warna yang realistis.
- 🧱 Struktur **Scene Graph** yang rapi (menggunakan `Group()`).
- 🔁 Transformasi posisi, rotasi, dan skala diterapkan secara modular.
- 🎥 Kamera bisa dikontrol dengan **OrbitControls**.
- 💻 Bisa dijalankan di browser & dipublikasikan di [itch.io](https://itch.io).

## 🚀 Cara Menjalankan (Lokal)

### 1. Siapkan lingkungan Python:

```bash
pip install -r requirements.txt
```
