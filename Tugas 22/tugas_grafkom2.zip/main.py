
import pygame
import sys

# Inisialisasi pygame
pygame.init()

# Ukuran layar
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Aplikasi Menggambar - Grafika Komputer")

# Warna default dan background
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
screen.fill(WHITE)
current_color = BLACK

# Mode menggambar
MODES = ["TITIK", "TITIK_BERSAMBUNG", "GARIS", "PERSEGI", "LINGKARAN", "ELIPSE"]
mode_index = 0
drawing = False
start_pos = None
points = []

font = pygame.font.SysFont(None, 24)

def draw_text(text, x, y):
    img = font.render(text, True, BLACK)
    screen.blit(img, (x, y))

def draw_temp_shape(mode, start, end):
    if mode == "GARIS":
        pygame.draw.line(screen, current_color, start, end, 2)
    elif mode == "PERSEGI":
        rect = pygame.Rect(*start, end[0]-start[0], end[1]-start[1])
        pygame.draw.rect(screen, current_color, rect, 2)
    elif mode == "LINGKARAN":
        radius = int(((end[0]-start[0])**2 + (end[1]-start[1])**2)**0.5)
        pygame.draw.circle(screen, current_color, start, radius, 2)
    elif mode == "ELIPSE":
        rect = pygame.Rect(min(start[0], end[0]), min(start[1], end[1]),
                           abs(end[0]-start[0]), abs(end[1]-start[1]))
        pygame.draw.ellipse(screen, current_color, rect, 2)

running = True
clock = pygame.time.Clock()

while running:
    clock.tick(60)
    screen.fill(WHITE)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if pygame.mouse.get_pressed()[0]:  # klik kiri
                if MODES[mode_index] in ["GARIS", "PERSEGI", "LINGKARAN", "ELIPSE"]:
                    start_pos = pygame.mouse.get_pos()
                    drawing = True
                elif MODES[mode_index] == "TITIK":
                    pos = pygame.mouse.get_pos()
                    pygame.draw.circle(screen, current_color, pos, 2)
                elif MODES[mode_index] == "TITIK_BERSAMBUNG":
                    pos = pygame.mouse.get_pos()
                    points.append(pos)

        elif event.type == pygame.MOUSEBUTTONUP:
            if drawing:
                end_pos = pygame.mouse.get_pos()
                draw_temp_shape(MODES[mode_index], start_pos, end_pos)
                drawing = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_m:
                mode_index = (mode_index + 1) % len(MODES)
            elif event.key == pygame.K_c:
                current_color = (255, 0, 0)
            elif event.key == pygame.K_b:
                current_color = (0, 0, 255)
            elif event.key == pygame.K_g:
                current_color = (0, 255, 0)
            elif event.key == pygame.K_k:
                current_color = (0, 0, 0)
            elif event.key == pygame.K_w:
                current_color = (255, 255, 255)
            elif event.key == pygame.K_x:
                screen.fill(WHITE)
                points.clear()

    # Gambar titik bersambung jika ada
    if MODES[mode_index] == "TITIK_BERSAMBUNG" and len(points) > 1:
        pygame.draw.lines(screen, current_color, False, points, 2)

    # Gambar bentuk sementara saat drag
    if drawing and start_pos:
        end_pos = pygame.mouse.get_pos()
        draw_temp_shape(MODES[mode_index], start_pos, end_pos)

    draw_text(f"Mode: {MODES[mode_index]}", 10, 10)
    draw_text("Tekan M untuk ganti mode", 10, 30)
    draw_text("C: Merah, G: Hijau, B: Biru, K: Hitam, W: Putih", 10, 50)
    draw_text("X: Clear Canvas", 10, 70)

    pygame.display.flip()

pygame.quit()
sys.exit()
