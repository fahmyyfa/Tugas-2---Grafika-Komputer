
Aplikasi Menggambar - Grafika Komputer

Deskripsi:
Program ini memungkinkan pengguna untuk menggambar titik, titik bersambung, garis, persegi, lingkaran, dan elips menggunakan mouse.

Kontrol:
- Tekan M : Ganti mode menggambar (Titik, Titik Bersambung, Garis, Persegi, Lingkaran, Elips)
- Klik Kiri Mouse : Menggambar sesuai mode aktif
- Tekan C : Ubah warna ke Merah
- Tekan G : Ubah warna ke Hijau
- Tekan B : Ubah warna ke Biru
- Tekan K : Ubah warna ke Hitam
- Tekan W : Ubah warna ke Putih
- Tekan X : Menghapus kanvas

Cara Menjalankan:
1. Pastikan Python dan pygame sudah terinstall (`pip install pygame`)
2. Jalankan file dengan `python main.py`

Catatan:
Tidak ada fitur penyimpanan gambar.
